export interface IotherDepartment{
    

}