export interface IproductType {
    name: string;
    id: number

}