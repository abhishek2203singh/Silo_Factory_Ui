export class IadminData {
    totalEmployees: number = 0;
    totalVendors: number = 0;
    pasteurizadMilk: number = 0;
    roughMilk: number = 0;
    totalMilk: number = 0;
    totalProducts: number = 0;
    totalMasterSilos: number = 0;
    totalPsSilos: number = 0;
    pendingApprovals: number = 0;
    totalDistributionCenters: number = 0;
    totalDepatments: number = 0;
    totalSilos: number = 0;
}