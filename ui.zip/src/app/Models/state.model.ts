type State = {
    id: number;
    name: string;
    country_id: number;
};


export default State;