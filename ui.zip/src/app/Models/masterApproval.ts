export interface ImasterApprovals {
    id: number,
    name: string,
    status: number,
    is_deletable: number
}