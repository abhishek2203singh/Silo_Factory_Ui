type Response = {
    success: boolean;
    message: string;
    event: string;
    data: any[];
};

export default Response