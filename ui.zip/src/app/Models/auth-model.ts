export class AuthModel {
    Id: any;
    access_token: any;
    token_type: any;
    expires_in: any;
    refresh_token: any;
    expires_time: any;
    AccessToken: any;
    message: any;
    err: any;
    roleId: any;
    code: any;
    type: any;
}
