export interface IsilosList {
    id: number,
    silo_name: string,
    capacity: number,
    total_available_milk: number
    status: number
    created_on: string
}