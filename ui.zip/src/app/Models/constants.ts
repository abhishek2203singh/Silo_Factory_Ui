export const Constants = {
    AuthData: "AuthData",
    UserProfile: "uProfile",
    LoggedInUser: "LoggedInUser",
    NoRecords: "No Records found",
    Id: "id",
    Title: "title"
}


