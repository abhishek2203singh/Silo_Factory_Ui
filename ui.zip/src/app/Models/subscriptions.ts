export class Subscriptions {
    id: number;
    deliveryBoyId?: number;
    userPrice: number;
    allDay: boolean;
    alternateDay: boolean;
    packingSizeId?: number;
    specificDay: boolean;
    productId: number;
    quantity: number;
    regularDay: boolean;
    shift: number;
    sunday: number;
    monday: number;
    tuesday: number;
    wednesday: number;
    thursday: number;
    friday: number;
    saturday: number;

}
