export interface ImasterEntryType {
    id: number,
    name: string,
    status: number,
    is_deletable: boolean
}