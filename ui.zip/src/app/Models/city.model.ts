type City = {
    id: number;
    name: string;
    state_id: number;
};
export default City;