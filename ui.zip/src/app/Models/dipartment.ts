export interface IDepartment {
    id: number;
    departmentName: string;
    priorityLevel: string;
    name: string;
    status: number;
    created_on: string;
    is_deletable: number;
};