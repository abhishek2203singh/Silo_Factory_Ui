// silo.model.ts
export interface Item {
    id: number;
    silo_name: string;
    capacity: number;
    total_available_milk: number;
    status: number;
}
