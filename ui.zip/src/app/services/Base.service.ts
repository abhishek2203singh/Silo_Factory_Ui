import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class BaseService {
    readonly url: string = "ws://localhost:4850";
    readonly httpurl: string = "http://localhost:4850";
    // readonly url: string = "ws://3.110.124.240:7070";
    // readonly httpurl: string = "http://3.110.124.240:7070";
    // Global Url variables 
    readonly imageurl: string = "https://ezeebuckt.s3.ap-south-1.amazonaws.com/Pious/";

    constructor(private http: HttpClient) {

    }

    Postimg(API: string, body: any) {
        const formData: FormData = new FormData();
        var file = body;
        // console.log("file in post=>", file)
        formData.append('file', file, body.name);
        const httpOptions = {
            headers: new HttpHeaders({
                //"Authorization": 'Bearer ' + this.GetAuthToken(),
                'Content-Type': 'application/json'
            })
        };
        return this.http.post(this.httpurl + '/' + API, formData)
    }

}
