import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { EmailValidators } from 'ngx-validators';
import { SocketService } from '../../services/Socket.service';
import { MenuService } from '../../services/menu.service';
import { CommonModule } from '@angular/common';
import { ToastrService, GlobalConfig } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { UtilityService } from '@services/utility.service';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        ReactiveFormsModule,
        CommonModule
    ],
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
    router: any;
    public form: FormGroup;
    public mobile: FormControl;
    public password: FormControl;
    private subscriptions: Subscription[] = [];
    msg: any = [];
    getd: any;
    currentUser: UserAccessInfo;
    constructor(router: Router, fb: FormBuilder, public toastr: ToastrService, private webSockets: SocketService, public menusev: MenuService, private util: UtilityService) {
        this.router = router;
        this.form = fb.group({
            mobile: ['', [
                Validators.required,
                Validators.pattern(/^\d{10}$/) // Regex for exactly 10 digits
            ]],
            password: ['', [
                Validators.required,
                Validators.minLength(6)
            ]],
            source: [1]
        });

        this.mobile = this.form.controls['mobile'] as FormControl;
        this.password = this.form.controls['password'] as FormControl;

        this.currentUser = util.getCurrentUser();
    }

    ngOnInit(): void {

        const sub1 = this.webSockets.listen('error').subscribe((res: any) => {
            this.toastr.error(res.event, res.message);
            this.getd = res;
            this.msg.push({ Mess: this.getd.message });
        });

        this.subscriptions.push(sub1);

        const sub = this.webSockets.listen('user:login').subscribe((res: any) => {
            try {
                if (res.success) {
                    const data = JSON.stringify(res.data);
                    localStorage.setItem('user', data);
                    localStorage.setItem('a', data);
                    this.webSockets.reconnect();

                    // Update the current user with the latest data
                    this.currentUser = res.data;
                    debugger
                    // Handle department and role-based navigation
                    if (res.data.departmentId == 6 && res.data.roleId == 4) {
                        this.menusev.DepartmentId = 6;
                        this.menusev.RoleId = 4;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/customer']);
                        return;
                    }

                    if (res.data.departmentId == 1 && res.data.roleId == 1) {
                        this.menusev.DepartmentId = 1;
                        this.menusev.RoleId = 1;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/admin']);
                        return;
                    }

                    // Handle other departments
                    if (this.currentUser.isOtherDpt) {
                        this.menusev.DepartmentId = this.currentUser.departmentId;
                        this.menusev.RoleId = this.currentUser.roleId;
                        this.toastr.success(res.message);
                        this.router.navigate([`pages/department/${this.currentUser.departmentId}`]);
                        return;
                    }

                    if (res.data.departmentId == 9 && res.data.roleId == 11) {
                        this.menusev.DepartmentId = 9;
                        this.menusev.RoleId = 11;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/qualitypanel']);
                        return;
                    }

                    if (res.data.departmentId == 5 && res.data.roleId == 3) {
                        this.menusev.DepartmentId = 5;
                        this.menusev.RoleId = 3;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/pasteurization']);
                        return;
                    }

                    if (res.data.departmentId == 4 && res.data.roleId == 3) {
                        this.menusev.DepartmentId = 4;
                        this.menusev.RoleId = 3;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/Silo-Department']);
                        return;
                    }

                    if (res.data.departmentId == 10 && res.data.roleId == 2) {
                        this.menusev.DepartmentId = 10;
                        this.menusev.RoleId = 2;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/qualitymanagerdashboard']);
                        return;
                    }

                    if (res.data.departmentId == 6 && res.data.roleId == 12) {
                        this.menusev.DepartmentId = 6;
                        this.menusev.RoleId = 12;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/distribution-center']);
                        return;
                    }

                    if (res.data.departmentId == 2 && res.data.roleId == 3) {
                        this.menusev.DepartmentId = 2;
                        this.menusev.RoleId = 3;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/stock-department']);
                        return;
                    }

                    if (res.data.departmentId == 3 && res.data.roleId == 3) {
                        this.menusev.DepartmentId = 3;
                        this.menusev.RoleId = 3;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/packaging-department']);
                        return;
                    }

                    if (res.data.departmentId == 7 && res.data.roleId == 8) {
                        this.menusev.DepartmentId = 7;
                        this.menusev.RoleId = 8;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/retail-shops']);
                        return;
                    }
                    if (res.data.departmentId == 8 && res.data.roleId == 5) {
                        this.menusev.DepartmentId = 7;
                        this.menusev.RoleId = 8;
                        this.toastr.success(res.message);
                        this.router.navigate(['/pages/vendor-dashboard']);
                        return;
                    }

                    // If none of the above conditions are met
                    this.toastr.error("User Not Valid");
                    return;
                }
                this.toastr.error(res.message);
            } catch (error) {
                this.toastr.error("Unable to connect to the server");
            }
        });


        this.subscriptions.push(sub);
    }

    ngOnDestroy(): void {
        this.subscriptions.forEach(sub => sub.unsubscribe());
    }

    login() {
        if (this.form.valid) {
            try {
                this.webSockets.emit("user:login", this.form.value);
            } catch (error) {
                // // console.log("Error =>", error)
                this.toastr.error("Unable to connect to the server");
            }
        }
    }

    ngAfterViewInit() {
        const preloader = document.getElementById('preloader');
        if (preloader) {
            preloader.classList.add('hide');
        }
    }
    showPassword: boolean = false;

    togglePasswordVisibility() {
        this.showPassword = !this.showPassword;
    }
}


type UserAccessInfo = {
    accessToken: string;
    code: number;
    departmentId: number;
    id: number;
    isOtherDpt: boolean;
    mobile: string;
    roleId: number;
    socketId: string;
};
