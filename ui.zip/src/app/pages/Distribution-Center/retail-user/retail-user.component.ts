import { Component } from '@angular/core';

@Component({
  selector: 'app-retail-user',
  standalone: true,
  imports: [],
  templateUrl: './retail-user.component.html',
  styleUrl: './retail-user.component.scss'
})
export class RetailUserComponent {

}
