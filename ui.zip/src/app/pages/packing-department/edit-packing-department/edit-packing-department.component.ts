import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-packing-department',
  standalone: true,
  imports: [],
  templateUrl: './edit-packing-department.component.html',
  styleUrl: './edit-packing-department.component.scss'
})
export class EditPackingDepartmentComponent {

}
