import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-menus',
  standalone: true,
  imports: [],
  templateUrl: './sub-menus.component.html',
  styleUrl: './sub-menus.component.scss'
})
export class SubMenusComponent {

}
