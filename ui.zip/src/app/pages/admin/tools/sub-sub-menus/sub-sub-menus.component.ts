import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-sub-menus',
  standalone: true,
  imports: [],
  templateUrl: './sub-sub-menus.component.html',
  styleUrl: './sub-sub-menus.component.scss'
})
export class SubSubMenusComponent {

}
