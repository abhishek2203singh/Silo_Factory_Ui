import { Component } from '@angular/core';

@Component({
  selector: 'app-unfinished-packaging-inventory',
  standalone: true,
  imports: [],
  templateUrl: './unfinished-packaging-inventory.component.html',
  styleUrl: './unfinished-packaging-inventory.component.scss'
})
export class UnfinishedPackagingInventoryComponent {

}
