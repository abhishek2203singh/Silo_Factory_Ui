export class Menu {
    constructor(
         id,
         title,
         routerLink,
         href,
         icon,
         target,
         hasSubMenu,
         parentId
        ) { 
            id,
            title,
            routerLink,
            href,
            icon,
            target,
            hasSubMenu,
            parentId
        }
} 