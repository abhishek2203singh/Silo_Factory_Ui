import { config as dotEnvConfig } from "dotenv";
dotEnvConfig();

const _config = {
    jwtKey: process.env.JWT_KEY,
    appMode: process.env.APP_MODE,
    debugMode: process.env.DEBUG_MODE,
    cloudName: process.env.CLOUD_NAME,
    cloudApiKey: process.env.CLOUD_API_KEY,
    cloudApiKeySecret: process.env.CLOUD_API_SECRET,
    maxFileSize: process.env.MAX_FILE_SIZE,
    port: process.env.PORT,
    corsOrigin: ["http://localhost:2121", "http://pious.kratitech.com", "exp://192.168.0.79:8081", "http://localhost:8081"],
};

export const config = Object.freeze(_config);
