# Rules

# DB standrads
- ## [1. Ensure that all table fields follow snake_case naming convention.](#rule-1)
- ## [2. For each transactional table, create a corresponding update table ](#rule-2)
- ## [3. Rule Title](#rule-3)




---

## [1. Ensure that all table fields follow snake_case naming convention.](#rule-1)
### Rule 1

// TODO: Ensure that all table fields follow snake_case naming convention. 
// Example: customer_details instead of customerDetails.


---

## [2. For each transactional table, create a corresponding update table ](#rule-2)
### Rule 2
// TODO: For each transactional table, create a corresponding update table 
// with the format: <transaction_table_name>_Update. 
// Example: For a table named 'orders', the update table should be 'orders_Update'.

---

## [3. Rule Title](#rule-3)
### Rule 3
Detailed description of rule 3.

<!-- Add more rules as needed -->























































# API Standard 
- ## [1. each event shold have meaning full names.](#rule-1)
- ## [2. For each transactional table, create a corresponding update table ](#rule-2)
- ## [3. Rule Title](#rule-3)


